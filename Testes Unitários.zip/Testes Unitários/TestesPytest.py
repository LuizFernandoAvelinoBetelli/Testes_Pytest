
# 1º Função a ser testada

def soma_total(precos):
    return sum(precos)

import pytest

# Definindo uma fixture que será usada para preparar os dados de teste
@pytest.fixture
def lista_de_precos():
    return [10, 20, 30, 40]

# Teste da função 'soma_total' usando a fixture
def test_soma_total(lista_de_precos):
    resultado = soma_total(lista_de_precos)
    assert resultado == 100  #A soma seja 100

# Teste com lista vazia para verificar se a função retorna zero
def test_soma_total_lista_vazia():
    resultado = soma_total([])
    assert resultado == 0  #A soma de uma lista vazia seja zero


#------------------------------------------------------------------------------------------------#

# # 2º Função a ser testada

# def maior_numero(numeros):
#     if not numeros:
#         return None  # Retorna None se a lista estiver vazia
#     return max(numeros)


# import pytest
# from TestesPytest import maior_numero

# # Teste para verificar se a função retorna o maior número de uma lista de valores positivos
# def test_maior_numero_positivo():
#     assert maior_numero([3, 7, 2, 9, 5]) == 9

# # Teste para verificar se a função retorna o maior número de uma lista de valores negativos
# def test_maior_numero_negativo():
#     assert maior_numero([-3, -7, -2, -9, -5]) == -2

# # Teste para verificar o comportamento com uma lista vazia
# def test_maior_numero_lista_vazia():
#     assert maior_numero([]) is None  #A função vai retornar None para lista vazia

# # Teste para verificar o comportamento com uma lista contendo apenas um número
# def test_maior_numero_um_elemento():
#     assert maior_numero([7]) == 7  #O único número seja retornado que é o 7

